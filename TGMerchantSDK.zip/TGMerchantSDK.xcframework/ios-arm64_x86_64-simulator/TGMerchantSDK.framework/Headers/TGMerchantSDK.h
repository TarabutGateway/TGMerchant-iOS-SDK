//
//  TGMerchantSDK.h
//  TGMerchantSDK
//
//  Created by Uzair Shahzad on 02/05/2023.
//

#import <Foundation/Foundation.h>

//! Project version number for TGMerchantSDK.
FOUNDATION_EXPORT double TGMerchantSDKVersionNumber;

//! Project version string for TGMerchantSDK.
FOUNDATION_EXPORT const unsigned char TGMerchantSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TGMerchantSDK/PublicHeader.h>


